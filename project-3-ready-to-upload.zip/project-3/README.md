# Project 3 — Collaborative Project Management Tool

A full-stack Trello/Asana-style project management application built with React, Node.js, Express, MongoDB, JWT, and Socket.IO.

## Features

- JWT authentication with bcrypt password hashing
- Create, edit, and delete projects
- Add/remove project members
- Kanban board: Todo, In Progress, Done
- Create, assign, edit, delete tasks
- Task priority and due dates
- Task comments
- In-app notifications
- Real-time task/comment updates with Socket.IO
- Responsive React UI
- Protected backend routes

## Tech Stack

Frontend: React, Vite, Tailwind CSS, Axios, React Router, Socket.IO Client  
Backend: Node.js, Express, MongoDB, Mongoose, JWT, bcryptjs, Socket.IO

## Requirements

- Node.js 18+
- MongoDB Atlas or local MongoDB
- npm

## Run locally

### 1. Backend

```bash
cd server
npm install
cp .env.example .env
npm run dev
```

Set `MONGO_URI` and `JWT_SECRET` in `.env`.

### 2. Frontend

```bash
cd client
npm install
cp .env.example .env
npm run dev
```

Open the Vite URL shown in the terminal.

## Default API

`http://localhost:5000/api`

## Socket.IO

The frontend connects to the backend Socket.IO server and joins a project room while a project board is open.

## Suggested GitHub workflow

```bash
git init
git add .
git commit -m "Initial commit - Project 3"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/project-3.git
git push -u origin main
```

Never commit `.env`. Use `.env.example` for public configuration templates.
