import { Router } from "express";
import Task from "../models/Task.js";
import Project from "../models/Project.js";
import { auth } from "../middleware/auth.js";
import { notify } from "../utils/notify.js";

const router = Router();
router.use(auth);

async function getProject(id,userId) {
  const p = await Project.findById(id);
  return p && (p.owner.equals(userId) || p.members.some(m=>m.equals(userId))) ? p : null;
}

router.post("/", async (req,res) => {
  try {
    const p = await getProject(req.body.project,req.user._id);
    if (!p) return res.status(403).json({message:"Access denied"});
    if (req.body.assignedTo && !p.members.some(m=>m.equals(req.body.assignedTo))) return res.status(400).json({message:"Assignee must be a project member"});
    let task = await Task.create({...req.body,createdBy:req.user._id});
    task = await task.populate("assignedTo","name email");
    task = await task.populate("createdBy","name email");
    req.app.get("io").to(`project:${p._id}`).emit("taskCreated",task);
    if (task.assignedTo && !task.assignedTo._id.equals(req.user._id)) {
      await notify({recipient:task.assignedTo._id,sender:req.user._id,type:"task_assigned",message:`You were assigned "${task.title}"`,project:p._id,task:task._id,io:req.app.get("io")});
    }
    res.status(201).json({task});
  } catch(err) { res.status(400).json({message:err.message}); }
});

router.get("/project/:projectId", async (req,res) => {
  const p = await getProject(req.params.projectId,req.user._id);
  if (!p) return res.status(403).json({message:"Access denied"});
  const tasks = await Task.find({project:p._id}).populate("assignedTo","name email").populate("createdBy","name email").sort("-createdAt");
  const counts = await Promise.all(tasks.map(async t => t._id));
  res.json({tasks:tasks.map(t=>({...t.toObject(),commentCount:0})), count:counts.length});
});

router.put("/:id", async (req,res) => {
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({message:"Task not found"});
  const p = await getProject(task.project,req.user._id);
  if (!p) return res.status(403).json({message:"Access denied"});
  if (req.body.assignedTo && !p.members.some(m=>m.equals(req.body.assignedTo))) return res.status(400).json({message:"Assignee must be a project member"});
  Object.assign(task,{title:req.body.title,description:req.body.description,priority:req.body.priority,assignedTo:req.body.assignedTo || null,dueDate:req.body.dueDate || null});
  await task.save();
  const populated = await task.populate("assignedTo","name email");
  await task.populate("createdBy","name email");
  req.app.get("io").to(`project:${p._id}`).emit("taskUpdated",populated);
  res.json({task:populated});
});

router.patch("/:id/status", async (req,res) => {
  const task = await Task.findById(req.params.id);
  if (!task) return res.status(404).json({message:"Task not found"});
  const p = await getProject(task.project,req.user._id);
  if (!p) return res.status(403).json({message:"Access denied"});
  if (!["Todo","In Progress","Done"].includes(req.body.status)) return res.status(400).json({message:"Invalid status"});
  task.status=req.body.status; await task.save();
  const populated=await task.populate("assignedTo","name email");
  await task.populate("createdBy","name email");
  req.app.get("io").to(`project:${p._id}`).emit("taskUpdated",populated);
  res.json({task:populated});
});

router.delete("/:id", async (req,res) => {
  const task=await Task.findById(req.params.id);
  if (!task) return res.status(404).json({message:"Task not found"});
  const p=await getProject(task.project,req.user._id);
  if (!p) return res.status(403).json({message:"Access denied"});
  await task.deleteOne();
  req.app.get("io").to(`project:${p._id}`).emit("taskDeleted",task._id);
  res.json({message:"Task deleted"});
});

export default router;
