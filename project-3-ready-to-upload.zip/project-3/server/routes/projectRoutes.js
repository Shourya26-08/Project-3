import { Router } from "express";
import Project from "../models/Project.js";
import User from "../models/User.js";
import { auth } from "../middleware/auth.js";
import { notify } from "../utils/notify.js";

const router = Router();
router.use(auth);

async function canAccess(project,userId) {
  return project && (project.owner.equals(userId) || project.members.some(m => m.equals(userId)));
}

router.post("/", async (req,res) => {
  try {
    const project = await Project.create({name:req.body.name,description:req.body.description || "",owner:req.user._id,members:[req.user._id]});
    res.status(201).json({project:await project.populate("members","name email")});
  } catch(err) { res.status(400).json({message:err.message}); }
});

router.get("/", async (req,res) => {
  const projects = await Project.find({members:req.user._id}).populate("members","name email").populate("owner","name email").sort("-updatedAt");
  res.json({projects});
});

router.get("/:id", async (req,res) => {
  const project = await Project.findById(req.params.id).populate("members","name email").populate("owner","name email");
  if (!await canAccess(project,req.user._id)) return res.status(403).json({message:"Access denied"});
  res.json({project});
});

router.post("/:id/members", async (req,res) => {
  const project = await Project.findById(req.params.id).populate("members","name email");
  if (!project || !project.owner.equals(req.user._id)) return res.status(403).json({message:"Only the owner can add members"});
  const user = await User.findOne({email:req.body.email?.toLowerCase()});
  if (!user) return res.status(404).json({message:"No user exists with that email"});
  if (project.members.some(m=>m._id.equals(user._id))) return res.status(409).json({message:"User is already a member"});
  project.members.push(user._id);
  await project.save();
  const populated = await project.populate("members","name email");
  await notify({recipient:user._id,sender:req.user._id,type:"project_added",message:`You were added to project "${project.name}"`,project:project._id,io:req.app.get("io")});
  res.json({project:populated});
});

router.delete("/:id", async (req,res) => {
  const project = await Project.findById(req.params.id);
  if (!project || !project.owner.equals(req.user._id)) return res.status(403).json({message:"Only the owner can delete the project"});
  await project.deleteOne();
  res.json({message:"Project deleted"});
});

export default router;
