import { Router } from "express";
import Notification from "../models/Notification.js";
import { auth } from "../middleware/auth.js";

const router=Router();
router.use(auth);

router.get("/",async(req,res)=>{
  const notifications=await Notification.find({recipient:req.user._id}).populate("sender","name email").sort("-createdAt").limit(50);
  res.json({notifications});
});

router.patch("/:id/read",async(req,res)=>{
  const notification=await Notification.findOneAndUpdate({_id:req.params.id,recipient:req.user._id},{isRead:true},{new:true});
  if(!notification) return res.status(404).json({message:"Notification not found"});
  res.json({notification});
});

export default router;
