import { Router } from "express";
import Comment from "../models/Comment.js";
import Task from "../models/Task.js";
import Project from "../models/Project.js";
import { auth } from "../middleware/auth.js";
import { notify } from "../utils/notify.js";

const router = Router();
router.use(auth);

async function access(task,userId) {
  const p=await Project.findById(task.project);
  return p && (p.owner.equals(userId) || p.members.some(m=>m.equals(userId))) ? p : null;
}

router.get("/task/:taskId", async (req,res) => {
  const task=await Task.findById(req.params.taskId);
  if (!task || !(await access(task,req.user._id))) return res.status(403).json({message:"Access denied"});
  const comments=await Comment.find({task:task._id}).populate("user","name email").sort("createdAt");
  res.json({comments});
});

router.post("/", async (req,res) => {
  const task=await Task.findById(req.body.task);
  const p=task && await access(task,req.user._id);
  if (!task || !p) return res.status(403).json({message:"Access denied"});
  const comment=await Comment.create({task:task._id,user:req.user._id,content:req.body.content});
  const populated=await comment.populate("user","name email");
  req.app.get("io").to(`project:${p._id}`).emit("commentAdded",populated);
  if (task.createdBy && !task.createdBy.equals(req.user._id)) {
    await notify({recipient:task.createdBy,sender:req.user._id,type:"comment",message:`New comment on "${task.title}"`,project:p._id,task:task._id,io:req.app.get("io")});
  }
  res.status(201).json({comment:populated});
});

export default router;
