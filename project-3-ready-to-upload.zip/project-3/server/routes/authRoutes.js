import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import User from "../models/User.js";
import { auth } from "../middleware/auth.js";

const router = Router();

function sign(id) {
  return jwt.sign({id}, process.env.JWT_SECRET, {expiresIn:"7d"});
}

router.post("/register", async (req,res) => {
  try {
    const {name,email,password} = req.body;
    if (!name || !email || !password) return res.status(400).json({message:"Name, email and password are required"});
    if (password.length < 6) return res.status(400).json({message:"Password must be at least 6 characters"});
    const exists = await User.findOne({email:email.toLowerCase()});
    if (exists) return res.status(409).json({message:"Email is already registered"});
    const user = await User.create({name,email,password:await bcrypt.hash(password,12)});
    res.status(201).json({token:sign(user._id), user:{_id:user._id,name:user.name,email:user.email}});
  } catch(err) { res.status(500).json({message:err.message}); }
});

router.post("/login", async (req,res) => {
  try {
    const {email,password} = req.body;
    const user = await User.findOne({email:email?.toLowerCase()});
    if (!user || !(await bcrypt.compare(password || "", user.password))) return res.status(401).json({message:"Invalid email or password"});
    res.json({token:sign(user._id), user:{_id:user._id,name:user.name,email:user.email}});
  } catch(err) { res.status(500).json({message:err.message}); }
});

router.get("/me", auth, (req,res)=>res.json({user:req.user}));

export default router;
