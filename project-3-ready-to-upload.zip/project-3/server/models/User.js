import mongoose from "mongoose";

const schema = new mongoose.Schema({
  name: {type:String, required:true, trim:true},
  email: {type:String, required:true, unique:true, lowercase:true, trim:true},
  password: {type:String, required:true},
  avatar: {type:String, default:""}
}, {timestamps:true});

export default mongoose.model("User", schema);
