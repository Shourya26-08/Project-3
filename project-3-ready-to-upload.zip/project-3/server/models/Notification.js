import mongoose from "mongoose";

const schema = new mongoose.Schema({
  recipient: {type:mongoose.Schema.Types.ObjectId, ref:"User", required:true},
  sender: {type:mongoose.Schema.Types.ObjectId, ref:"User", default:null},
  type: {type:String, required:true},
  message: {type:String, required:true},
  project: {type:mongoose.Schema.Types.ObjectId, ref:"Project", default:null},
  task: {type:mongoose.Schema.Types.ObjectId, ref:"Task", default:null},
  isRead: {type:Boolean, default:false}
}, {timestamps:true});

export default mongoose.model("Notification", schema);
