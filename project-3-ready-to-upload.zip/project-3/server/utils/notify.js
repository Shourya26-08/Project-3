import Notification from "../models/Notification.js";

export async function notify({recipient, sender=null, type, message, project=null, task=null, io=null}) {
  const notification = await Notification.create({recipient, sender, type, message, project, task});
  const populated = await notification.populate("sender", "name email");
  if (io) io.to(`user:${recipient}`).emit("notificationCreated", populated);
  return populated;
}
