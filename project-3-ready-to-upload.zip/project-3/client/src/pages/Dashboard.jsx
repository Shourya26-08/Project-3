import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Plus, FolderKanban } from "lucide-react";
import Layout from "../components/Layout";
import api from "../lib/api";

export default function Dashboard() {
  const [projects,setProjects] = useState([]);
  const [show,setShow] = useState(false);
  const [form,setForm] = useState({name:"",description:""});
  const [error,setError] = useState("");

  async function load() {
    const {data} = await api.get("/projects");
    setProjects(data.projects);
  }
  useEffect(()=>{load()},[]);

  async function create(e) {
    e.preventDefault(); setError("");
    try {
      await api.post("/projects", form);
      setForm({name:"",description:""}); setShow(false); load();
    } catch(err) { setError(err.response?.data?.message || "Could not create project"); }
  }

  return <Layout>
    <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
      <div><p className="text-sm font-semibold text-indigo-600">Workspace</p><h1 className="text-3xl font-bold">Your projects</h1><p className="mt-1 text-slate-500">Plan, assign and collaborate with your team.</p></div>
      <button onClick={()=>setShow(true)} className="btn-primary flex items-center gap-2"><Plus size={17}/> New project</button>
    </div>

    {show && <div className="card mb-6 p-5">
      <form onSubmit={create} className="grid gap-3 md:grid-cols-[1fr_2fr_auto]">
        <input className="input" placeholder="Project name" required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
        <input className="input" placeholder="Short description" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/>
        <div className="flex gap-2"><button className="btn-primary">Create</button><button type="button" onClick={()=>setShow(false)} className="btn-secondary">Cancel</button></div>
      </form>
      {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
    </div>}

    {projects.length ? <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {projects.map(p=><Link key={p._id} to={`/projects/${p._id}`} className="card block p-5 transition hover:-translate-y-1 hover:shadow-md">
        <div className="mb-5 flex items-center justify-between"><div className="grid h-11 w-11 place-items-center rounded-xl bg-indigo-50 text-indigo-600"><FolderKanban/></div><span className="text-xs text-slate-400">{p.members?.length || 0} members</span></div>
        <h2 className="text-lg font-bold">{p.name}</h2><p className="mt-1 line-clamp-2 text-sm text-slate-500">{p.description || "No description."}</p>
      </Link>)}
    </div> : <div className="card py-16 text-center"><FolderKanban className="mx-auto mb-3 text-slate-300" size={42}/><p className="font-semibold">No projects yet</p><p className="mt-1 text-sm text-slate-500">Create your first project to get started.</p></div>}
  </Layout>;
}
