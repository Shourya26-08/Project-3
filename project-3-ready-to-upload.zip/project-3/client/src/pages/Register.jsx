import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({name:"",email:"",password:""});
  const [error,setError] = useState("");

  async function submit(e) {
    e.preventDefault(); setError("");
    try { await register(form.name, form.email, form.password); navigate("/"); }
    catch (err) { setError(err.response?.data?.message || "Registration failed"); }
  }

  return <div className="grid min-h-screen place-items-center bg-gradient-to-br from-indigo-50 via-white to-slate-100 p-4">
    <div className="w-full max-w-md rounded-3xl border border-slate-200 bg-white p-8 shadow-xl">
      <div className="mb-7 text-center"><div className="mx-auto mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-indigo-600 font-bold text-white">P3</div><h1 className="text-2xl font-bold">Create account</h1><p className="mt-1 text-sm text-slate-500">Start collaborating on Project 3.</p></div>
      <form onSubmit={submit} className="space-y-4">
        {error && <div className="rounded-xl bg-red-50 p-3 text-sm text-red-600">{error}</div>}
        <input className="input" placeholder="Full name" required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
        <input className="input" type="email" placeholder="Email" required value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/>
        <input className="input" type="password" minLength="6" placeholder="Password (6+ characters)" required value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>
        <button className="btn-primary w-full">Create account</button>
        <p className="text-center text-sm text-slate-500">Already registered? <Link className="font-semibold text-indigo-600" to="/login">Login</Link></p>
      </form>
    </div>
  </div>;
}
