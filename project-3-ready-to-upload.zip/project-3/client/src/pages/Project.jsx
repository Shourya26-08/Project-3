import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Plus, Trash2, UserPlus } from "lucide-react";
import { Link, useParams } from "react-router-dom";
import { io } from "socket.io-client";
import Layout from "../components/Layout";
import TaskCard from "../components/TaskCard";
import TaskModal from "../components/TaskModal";
import api from "../lib/api";

const columns = [
  {key:"Todo", label:"To Do"},
  {key:"In Progress", label:"In Progress"},
  {key:"Done", label:"Done"}
];

export default function Project() {
  const {id} = useParams();
  const [project,setProject] = useState(null);
  const [tasks,setTasks] = useState([]);
  const [members,setMembers] = useState([]);
  const [users,setUsers] = useState([]);
  const [selected,setSelected] = useState(null);
  const [showTask,setShowTask] = useState(false);
  const [form,setForm] = useState({title:"",description:"",priority:"Medium",assignedTo:"",dueDate:""});
  const [email,setEmail] = useState("");
  const [notice,setNotice] = useState("");

  async function load() {
    const [p,t] = await Promise.all([api.get(`/projects/${id}`), api.get(`/tasks/project/${id}`)]);
    setProject(p.data.project); setMembers(p.data.project.members || []); setTasks(t.data.tasks);
  }

  useEffect(() => {
    load();
    const socket = io(import.meta.env.VITE_SOCKET_URL || "http://localhost:5000", {
      auth: { token: localStorage.getItem("project3_token") }
    });
    socket.emit("joinProject", id);
    socket.on("taskCreated", task => setTasks(prev => prev.some(x=>x._id===task._id) ? prev : [...prev,task]));
    socket.on("taskUpdated", task => setTasks(prev => prev.map(x=>x._id===task._id ? task : x)));
    socket.on("taskDeleted", taskId => setTasks(prev => prev.filter(x=>x._id!==taskId)));
    socket.on("commentAdded", () => {});
    return () => socket.disconnect();
  }, [id]);

  const grouped = useMemo(() => Object.fromEntries(columns.map(c => [c.key, tasks.filter(t=>t.status===c.key)])), [tasks]);

  async function createTask(e) {
    e.preventDefault();
    const {data} = await api.post("/tasks", {...form, project:id});
    setTasks(prev=>[...prev,data.task]); setForm({title:"",description:"",priority:"Medium",assignedTo:"",dueDate:""}); setShowTask(false);
  }

  async function moveTask(task, status) {
    const {data} = await api.patch(`/tasks/${task._id}/status`, {status});
    setTasks(prev=>prev.map(t=>t._id===task._id ? data.task : t));
  }

  async function deleteTask(task) {
    if (!confirm(`Delete "${task.title}"?`)) return;
    await api.delete(`/tasks/${task._id}`);
    setTasks(prev=>prev.filter(t=>t._id!==task._id));
  }

  async function addMember(e) {
    e.preventDefault();
    try {
      const {data} = await api.post(`/projects/${id}/members`, {email});
      setProject(data.project); setMembers(data.project.members); setEmail(""); setNotice("Member added.");
    } catch(err) { setNotice(err.response?.data?.message || "Could not add member."); }
  }

  async function updateTask(updated) {
    setTasks(prev=>prev.map(t=>t._id===updated._id ? updated : t));
  }

  if (!project) return <Layout><div>Loading project...</div></Layout>;

  return <Layout>
    <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
      <div>
        <Link to="/" className="mb-3 inline-flex items-center gap-1 text-sm font-semibold text-indigo-600"><ArrowLeft size={15}/> Back to projects</Link>
        <h1 className="text-3xl font-bold">{project.name}</h1><p className="text-slate-500">{project.description}</p>
      </div>
      <button onClick={()=>setShowTask(true)} className="btn-primary flex items-center gap-2"><Plus size={17}/> Add task</button>
    </div>

    <div className="mb-6 card p-4">
      <div className="mb-3 flex items-center gap-2 font-semibold"><UserPlus size={17}/> Add team member</div>
      <form onSubmit={addMember} className="flex max-w-xl gap-2"><input className="input" type="email" placeholder="Member email" required value={email} onChange={e=>setEmail(e.target.value)}/><button className="btn-secondary">Add</button></form>
      {notice && <p className="mt-2 text-sm text-slate-500">{notice}</p>}
      <div className="mt-3 flex flex-wrap gap-2">{members.map(m=><span key={m._id} className="rounded-full bg-slate-100 px-3 py-1 text-xs">{m.name} · {m.email}</span>)}</div>
    </div>

    {showTask && <div className="card mb-6 p-5">
      <h2 className="mb-4 font-bold">Create task</h2>
      <form onSubmit={createTask} className="space-y-3">
        <input className="input" placeholder="Task title" required value={form.title} onChange={e=>setForm({...form,title:e.target.value})}/>
        <textarea className="input min-h-24" placeholder="Description" value={form.description} onChange={e=>setForm({...form,description:e.target.value})}/>
        <div className="grid gap-3 sm:grid-cols-3">
          <select className="input" value={form.priority} onChange={e=>setForm({...form,priority:e.target.value})}><option>Low</option><option>Medium</option><option>High</option></select>
          <select className="input" value={form.assignedTo} onChange={e=>setForm({...form,assignedTo:e.target.value})}><option value="">Unassigned</option>{members.map(m=><option key={m._id} value={m._id}>{m.name}</option>)}</select>
          <input className="input" type="date" value={form.dueDate} onChange={e=>setForm({...form,dueDate:e.target.value})}/>
        </div>
        <div className="flex gap-2"><button className="btn-primary">Create task</button><button type="button" className="btn-secondary" onClick={()=>setShowTask(false)}>Cancel</button></div>
      </form>
    </div>}

    <div className="grid gap-5 lg:grid-cols-3">
      {columns.map(c=><section key={c.key} className="min-h-[500px] rounded-2xl bg-slate-100 p-4">
        <div className="mb-4 flex items-center justify-between"><h2 className="font-bold">{c.label}</h2><span className="rounded-full bg-white px-2 py-1 text-xs text-slate-500">{grouped[c.key]?.length || 0}</span></div>
        <div className="space-y-3">
          {(grouped[c.key] || []).map(task=><div key={task._id} className="group relative">
            <TaskCard task={task} onClick={()=>setSelected(task)}/>
            <div className="mt-1 flex gap-1 opacity-0 transition group-hover:opacity-100">
              {columns.filter(x=>x.key!==task.status).map(x=><button key={x.key} onClick={()=>moveTask(task,x.key)} className="rounded-lg bg-white px-2 py-1 text-[11px] text-slate-600 shadow-sm">Move to {x.label}</button>)}
              <button onClick={()=>deleteTask(task)} className="rounded-lg bg-white p-1 text-red-500 shadow-sm"><Trash2 size={13}/></button>
            </div>
          </div>)}
          {!grouped[c.key]?.length && <div className="rounded-xl border-2 border-dashed border-slate-200 p-8 text-center text-sm text-slate-400">No tasks</div>}
        </div>
      </section>)}
    </div>

    {selected && <TaskModal task={selected} members={members} onClose={()=>setSelected(null)} onSaved={updateTask}/>}
  </Layout>;
}
