import { CalendarDays, MessageCircle, UserRound } from "lucide-react";

const priorityStyles = {
  Low: "bg-emerald-50 text-emerald-700",
  Medium: "bg-amber-50 text-amber-700",
  High: "bg-red-50 text-red-700"
};

export default function TaskCard({ task, onClick }) {
  return (
    <button onClick={onClick} className="w-full rounded-xl border border-slate-200 bg-white p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md">
      <div className="mb-2 flex items-start justify-between gap-2">
        <h3 className="font-semibold text-slate-800">{task.title}</h3>
        <span className={`rounded-full px-2 py-1 text-[11px] font-bold ${priorityStyles[task.priority] || priorityStyles.Medium}`}>
          {task.priority}
        </span>
      </div>
      {task.description && <p className="mb-3 line-clamp-2 text-sm text-slate-500">{task.description}</p>}
      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
        {task.assignedTo && <span className="flex items-center gap-1"><UserRound size={13}/>{task.assignedTo.name}</span>}
        {task.dueDate && <span className="flex items-center gap-1"><CalendarDays size={13}/>{new Date(task.dueDate).toLocaleDateString()}</span>}
        <span className="flex items-center gap-1"><MessageCircle size={13}/>{task.commentCount || 0}</span>
      </div>
    </button>
  );
}
