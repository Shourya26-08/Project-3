import { useEffect, useState } from "react";
import { X } from "lucide-react";
import api from "../lib/api";

export default function TaskModal({ task, members, onClose, onSaved }) {
  const [form, setForm] = useState({
    title: task?.title || "",
    description: task?.description || "",
    priority: task?.priority || "Medium",
    assignedTo: task?.assignedTo?._id || task?.assignedTo || "",
    dueDate: task?.dueDate ? task.dueDate.slice(0, 10) : ""
  });
  const [comments, setComments] = useState([]);
  const [comment, setComment] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!task) return;
    api.get(`/comments/task/${task._id}`).then(r => setComments(r.data.comments));
  }, [task]);

  if (!task) return null;

  async function save(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const { data } = await api.put(`/tasks/${task._id}`, form);
      onSaved(data.task);
      onClose();
    } finally {
      setSaving(false);
    }
  }

  async function addComment(e) {
    e.preventDefault();
    if (!comment.trim()) return;
    const { data } = await api.post("/comments", { task: task._id, content: comment });
    setComments(c => [...c, data.comment]);
    setComment("");
  }

  return (
    <div className="fixed inset-0 z-50 grid place-items-center bg-slate-950/50 p-4">
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl bg-white p-6 shadow-2xl">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-xl font-bold">Task details</h2>
          <button onClick={onClose} className="rounded-lg p-2 hover:bg-slate-100"><X/></button>
        </div>

        <form onSubmit={save} className="space-y-4">
          <input className="input" value={form.title} onChange={e => setForm({...form, title:e.target.value})} required />
          <textarea className="input min-h-28" placeholder="Description" value={form.description} onChange={e => setForm({...form, description:e.target.value})}/>
          <div className="grid gap-4 sm:grid-cols-3">
            <select className="input" value={form.priority} onChange={e => setForm({...form, priority:e.target.value})}>
              <option>Low</option><option>Medium</option><option>High</option>
            </select>
            <select className="input" value={form.assignedTo} onChange={e => setForm({...form, assignedTo:e.target.value})}>
              <option value="">Unassigned</option>
              {members.map(m => <option key={m._id} value={m._id}>{m.name}</option>)}
            </select>
            <input className="input" type="date" value={form.dueDate} onChange={e => setForm({...form, dueDate:e.target.value})}/>
          </div>
          <button disabled={saving} className="btn-primary">{saving ? "Saving..." : "Save changes"}</button>
        </form>

        <div className="mt-8 border-t pt-6">
          <h3 className="mb-3 font-bold">Comments</h3>
          <div className="space-y-3">
            {comments.map(c => (
              <div key={c._id} className="rounded-xl bg-slate-50 p-3">
                <div className="text-sm font-semibold">{c.user?.name}</div>
                <div className="text-sm text-slate-600">{c.content}</div>
                <div className="mt-1 text-[11px] text-slate-400">{new Date(c.createdAt).toLocaleString()}</div>
              </div>
            ))}
            {!comments.length && <p className="text-sm text-slate-400">No comments yet.</p>}
          </div>
          <form onSubmit={addComment} className="mt-4 flex gap-2">
            <input className="input" placeholder="Write a comment..." value={comment} onChange={e => setComment(e.target.value)}/>
            <button className="btn-primary">Send</button>
          </form>
        </div>
      </div>
    </div>
  );
}
